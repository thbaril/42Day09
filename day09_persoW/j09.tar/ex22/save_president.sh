#!/bin/sh
alias rm="ls"
