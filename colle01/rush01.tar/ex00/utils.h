/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: opascal <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/09/10 21:11:52 by opascal           #+#    #+#             */
/*   Updated: 2017/09/10 21:11:53 by opascal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UTILS_H
# define UTILS_H

void	ft_throw_error(void);
int		ft_strlen(char *str);
int		ft_putchar(char c);
void	ft_putstr(char *str);

#endif
