/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: opascal <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/09/10 21:05:44 by opascal           #+#    #+#             */
/*   Updated: 2017/09/10 21:05:45 by opascal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SUDOKU_H
# define SUDOKU_H

# define N (9)
# define N3 (N / 3)

# define EXIT_SUCCESS 0
# define EXIT_FAILURE 1
# define ERR_ARGS_BAD_COUNT 1
# define ERR_ARGS_BAD_LINE_LENGTH 2
# define ERR_ARGS_BAD_CHAR 3
# define ERR_GRID_BAD_SOLUTIONS_COUNT 4
# define ERR_GRID_INVALID 5

#endif
